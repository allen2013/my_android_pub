/** Automatically generated file. DO NOT MODIFY */
package com.dragonflow.genie.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}