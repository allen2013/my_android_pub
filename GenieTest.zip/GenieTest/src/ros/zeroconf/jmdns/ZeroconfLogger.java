package ros.zeroconf.jmdns;

import java.lang.String;

public interface ZeroconfLogger {
	public void println(String msg);
}
