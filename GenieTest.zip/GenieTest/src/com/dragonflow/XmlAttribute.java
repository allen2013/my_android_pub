package com.dragonflow;

public class XmlAttribute {
	String name;
	String value;
	XmlAttribute(String n,String v)
	{
		name = n;
		value = v;
	}
}
