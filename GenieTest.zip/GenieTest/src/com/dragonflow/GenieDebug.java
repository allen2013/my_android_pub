package com.dragonflow;

import android.util.Log;

public class GenieDebug {
	
	public static final void error(String tag, String msg) {
		
		Log.i(tag, msg);
		
		
	}
}
