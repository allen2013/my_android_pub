package com.dragonflow;

import com.netgear.genie.media.dlna.DLNAObjectList;

public class DLNABrowseList {
	String parentobjid;
	
	DLNAObjectList objlist;
}
