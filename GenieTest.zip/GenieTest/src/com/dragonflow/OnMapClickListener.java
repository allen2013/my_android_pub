package com.dragonflow;

public interface OnMapClickListener {
	
	void onClick(mapview view, int Index, int Value,boolean gateway);
}
