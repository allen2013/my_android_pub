package com.dragonflow;

public class GenieDlnaRenderListItem {
	String m_FriendlyName;
	boolean m_select = false;
	boolean m_iconflag;
	byte[]  m_icon;	
}
