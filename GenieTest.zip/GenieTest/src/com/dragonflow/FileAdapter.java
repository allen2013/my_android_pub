package com.dragonflow;

public interface FileAdapter {
	
	/**
	 * */
	public int getLayoutId();
	
	public int getIconId();
	
	public int getFileNameTextId();
	
	
}
