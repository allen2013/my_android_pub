package com.dragonflow;

import android.graphics.Bitmap;

public class DeviceInfo {
	public int x;
	public int y;
	public int w;
	public int h;
	public int type;
	public int bmpx ;
	public int bmpy ;
	public boolean clicked = false;
	public String Ip;
	public String name;
	public String mac;
	public String ConnectionType;
	public Bitmap bmp = null;
	//public Bitmap clickbmp = null;
	
	//
	public Bitmap wlbmp = null; 
	public String speed; 
	public String intensity; 
	public String blockstatus; 
	
	public boolean isturbo=true;
}
