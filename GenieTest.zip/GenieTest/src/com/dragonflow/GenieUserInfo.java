package com.dragonflow;

public class GenieUserInfo 
{
	public char starttime;
	public char worktime;
	public char isSave;
	public char username[] = new char[40];
	public char password[] = new char[40];
	public char routerMac[] = new char[40];
	public char PCUsername[] = new char[40];
	public char PCPassword[] = new char[40];
	public char PCDeviceID[] = new char[40];
	public char PCLoginToken[] = new char[40];
	public char TimeMac[] = new char[40];
	public char start_time[] = new char[40];
	public char disabletime[] = new char[40];
}
