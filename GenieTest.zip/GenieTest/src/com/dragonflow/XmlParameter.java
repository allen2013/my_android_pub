package com.dragonflow;

import java.util.ArrayList;

public class XmlParameter {
	String  Tag;
	String  text;
	ArrayList<XmlAttribute> attribute;
	ArrayList<XmlParameter> child;
}
