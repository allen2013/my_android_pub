package com.netgear.genie.media.dlna;

public class DLNAAVTransport {
	 public String m_TransportStatus;
	 public String m_TransportState;
	 public String m_CurrentTrackDuration;
	 public long m_TrackDurationInMillis;
}
