package com.netgear.genie.media.dlna;

public class DLNARenderingControl {
	public int m_Mute;
	public int m_Volume;
	public int m_MaxVolume;
}
