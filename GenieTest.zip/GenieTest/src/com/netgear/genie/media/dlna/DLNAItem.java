package com.netgear.genie.media.dlna;

public class DLNAItem extends DLNAObject {
}
