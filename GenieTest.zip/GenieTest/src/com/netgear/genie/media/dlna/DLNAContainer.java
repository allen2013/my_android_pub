package com.netgear.genie.media.dlna;

public class DLNAContainer extends DLNAObject {
}
