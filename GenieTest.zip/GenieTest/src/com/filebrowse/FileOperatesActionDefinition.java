package com.filebrowse;

public class FileOperatesActionDefinition {
	
	public static final String LOCATION_NEW="oprates.location.new";
	public static final String LOCATION_SHOWLIST="oprates.location.showlist";
	public static final String LOCATION_SHOWGRID="oprates.location.showgrid";
	public static final String LOCATION_UP="oprates.location.up";

}
